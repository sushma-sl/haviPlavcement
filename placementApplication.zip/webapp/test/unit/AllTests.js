sap.ui.define([
	"com/placementApplication/test/unit/controller/View1.controller"
], function () {
	"use strict";
});