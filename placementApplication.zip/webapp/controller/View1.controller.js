sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel"
], function (Controller, JSONModel) {
	"use strict";

	return Controller.extend("com.placementApplication.controller.View1", {
		onInit: function () {
			var oWorklistView = new JSONModel({
				bSignUp: false,
				bLog: false
			});
			this.getView().setModel(oWorklistView, "worklistView");
			$.ajax({
				type: "GET",

				url: 'https://api.appery.io/rest/1/db/collections/SignUp/<object_id>',
				headers: {
					'X-Appery-Database-Id': '5f86f82b2e22d7027ca0c724',
				},
				dataType: "json",

				success: function (data) {
					console.log(data);
				}

			});

		},
		onPress: function (oEvent) {
			var worklistView = this.getView().getModel("worklistView");
			if (oEvent.getSource().getText() === "Sign Up") {
				worklistView.setProperty("/bSignUp", true);
				worklistView.setProperty("/bLog", false);
				// this.onPressTest();
			} else {
				worklistView.setProperty("/bSignUp", false);
				worklistView.setProperty("/bLog", true);
			}
		},
		onPressTest: function () {
			var that = this;
			// var router = sap.ui.core.UIComponent.getRouterFor(that);
			// 			router.navTo("detailPage");

			var worklistView = this.getView().getModel("worklistView");
			var globalModel = this.getOwnerComponent().getModel("oGlobalModel");
			if (worklistView.getProperty("/bSignUp") === true) {
				var test = {
					"Lastname": worklistView.getProperty("/Lastname"),
					"dob": worklistView.getProperty("/dob"),
					"phonenumber": worklistView.getProperty("/phonenumber"),
					"email": worklistView.getProperty("/email"),
					"userName": worklistView.getProperty("/userName"),
					"password": worklistView.getProperty("/password")
				};
				$.ajax({
					type: "POST",
					url: "https://api.appery.io/rest/1/apiexpress/api/placement/signup?apiKey=db7ec399-f308-4aa3-b6aa-453fd0b042d1", //replace with my email
					dataType: "json",
					data: JSON.stringify(test),
					success: function (data) {
						console.log(data);
						sap.m.MessageBox.show("User Created with user ID :" + data._id);
						globalModel.setProperty("/LogedinData", data);
						worklistView.setProperty("/bSignUp", false);
						worklistView.setProperty("/bLog", false);

						worklistView.setProperty("/Lastname", "");
						worklistView.setProperty("/dob", "");
						worklistView.setProperty("/phonenumber", "");
						worklistView.setProperty("/email", "");
						worklistView.setProperty("/userName", "");
						worklistView.setProperty("/password", "");
						var router = sap.ui.core.UIComponent.getRouterFor(that);
						router.navTo("detailPage");

					}

				});
			} else {

				var globalModel = this.getOwnerComponent().getModel("oGlobalModel");
				var api = worklistView.getProperty("/loggedinUserId");
				var url = "https://api.appery.io/rest/1/apiexpress/api/placement/signup/" + api + "?apiKey=db7ec399-f308-4aa3-b6aa-453fd0b042d1";

				$.ajax({
					type: "GET",

					url: url,
					dataType: "json",
					data: JSON.stringify(test),
					success: function (data) {
						console.log(data);
						globalModel.setProperty("/LogedinData", data);
						var router = sap.ui.core.UIComponent.getRouterFor(that);
						router.navTo("detailPage");
						// sap.m.MessageBox.show("User Created with user ID :" + data._id);

					},
					error:function(data){
						
					}

				});

			}
		},
	});
});